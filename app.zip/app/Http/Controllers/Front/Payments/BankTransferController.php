<?php

namespace App\Http\Controllers\Front\Payments;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BankTransferController extends Controller
{
  
}