<?php

namespace App\Http\Controllers\Front;

use App\Shop\Customers\Customer;
use App\Http\Controllers\Controller;
use App\Shop\Orders\Order;
use DB;

class AccountsController extends Controller
{
   
}
