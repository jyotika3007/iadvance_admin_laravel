<?php

namespace App\Http\Controllers\Admin\Cities;

use App\Shop\Cities\City;
use App\Http\Controllers\Controller;

class CityController extends Controller
{
    
}
