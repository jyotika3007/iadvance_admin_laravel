<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppleService extends Model
{
    //
}
