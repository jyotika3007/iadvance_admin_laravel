<?php

namespace App\Shop;

use Illuminate\Database\Eloquent\Model;

class ProductWeight extends Model
{
    //
}
