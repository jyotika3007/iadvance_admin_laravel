<?php

namespace App\Shop\Booking;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    //
}
