<?php

namespace App\Shop\Brands;

use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    protected $fillable = ['name','user_id','cover'];

   
}
