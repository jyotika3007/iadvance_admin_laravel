<?php

namespace App\Shop\NewsletterPosts;

use Illuminate\Database\Eloquent\Model;

class NewletterPost extends Model
{
    //
}
