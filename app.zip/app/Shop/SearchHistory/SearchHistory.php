<?php

namespace App\Shop\SearchHistory;

use Illuminate\Database\Eloquent\Model;

class SearchHistory extends Model
{
    //
}
