<?php

namespace App\Shop\Contact;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    //
}
